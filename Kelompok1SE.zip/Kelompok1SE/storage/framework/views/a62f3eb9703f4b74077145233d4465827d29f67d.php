

<?php $__env->startSection('title', 'Xiao Ding Dong'); ?>

<?php $__env->startSection('content'); ?>
    <<div class="container mt-5">
      <h1 class="text-info text-warning">菜单 | Menu</h1><br>
      <button type="button" class="btn text-warning" style="background-color: rgb(34, 32, 32)">主菜 | Main Course</button>
      <button type="button" class="btn text-warning" style="background-color: rgb(34, 32, 32)">饮料 | Beverages</button>
      <button type="button" class="btn text-warning" style="background-color: rgb(34, 32, 32)">甜点 | Desserts</button>
  </div> 
  <br>
  <div class="container">
    <div class="row">
      <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mb-4">
          <a href="your-link-url">
            <div class="card" style="width: 23rem; background-color:rgb(34, 32, 32)">
              <img src="./foodImages/mapo_tofu.jpg" class="card-img-top" alt="Image Alt Text">
              <div class="card-body">
                <h5 class="card-title text-warning"><?php echo e($item->item_name); ?></h5>
              </div>
            </div>
          </a>
        </div>   
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./components/GuestNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DARREN ENGELBERT\Desktop\BINUS\SEM5\Web Programming\Project Web Programming\Project_Lab\resources\views/Guest.blade.php ENDPATH**/ ?>