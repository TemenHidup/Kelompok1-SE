<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<style>
    .card-fixed-size {
        height: 300px; 
    }
    .card-image {
    object-fit: cover; 
    width: 100%; 
    height: 100%; 
}
</style>

<body>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
        <?php echo $__env->make('./components/AdminNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isUser')): ?>
            <?php echo $__env->make('./components/UserNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('./components/GuestNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
    
    <?php echo $__env->yieldContent('error'); ?>
    <?php echo $__env->yieldContent('banner'); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('footer'); ?>

</body>
</html><?php /**PATH C:\Users\DARREN ENGELBERT\Desktop\BINUS\SEM5\Web Programming\Project Web Programming\Project_Lab\resources\views///components/mainNav.blade.php ENDPATH**/ ?>