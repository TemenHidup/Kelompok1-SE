

<?php $__env->startSection('title', 'Xiao Ding Dong | Admin'); ?>

<?php $__env->startSection('content'); ?>
    <h1>菜单|Menu</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./components/AdminNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DARREN ENGELBERT\Desktop\BINUS\SEM5\Web Programming\Project Web Programming\Project_Lab\resources\views/Admin.blade.php ENDPATH**/ ?>