


<?php $__env->startSection('title', 'Xiao Ding Dong'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class = "container mt-3 text-warning">搜索食物 | Search Food</h1>
    <div class = "container mt-3">
        <form action="/search" method = "POST">
            <div class="input-group mb-3 ">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control w-75" placeholder="Search" name = "search">
                <button class="btn btn-dark my-2 my-sm-0 text-white" type="submit" name = "button"  value ="1">Search</button>
            </div>
        </form>
        <div style="color: white; background-color:rgb(22, 22, 22)">
            <form id="search-form" action="<?php echo e(route('submit')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label><input type="checkbox" name="category[]" value="Main Course">Main Course</label>
                <label><input type="checkbox" name="category[]" value="Dessert">Dessert</label>
                <label><input type="checkbox" name="category[]" value="Beverage">Beverage</label> 
            </form>
        </div>
        <hr>
        <?php if($items->isEmpty()): ?>
        <div class="container" style="background-color: rgb(37, 37, 37); height:40px; text-align:center; color:white"><h5>Food is not available</h5></div>
        <?php endif; ?>
        <br>

        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-3">
                <a href="<?php echo e(url('foodDetail', $item->id)); ?>" style="text-decoration: none;">
                <div class="card" style="background-color:rgb(22, 22, 22)">
                    <div class="row no-gutters">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('foodImages/' .$item->item_image)); ?>" class="card-img" alt="Card image">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body text-white">
                                <h5 class="card-title"><?php echo e($item->item_name); ?></h5>
                                <h6>category</h6>
                                <p class="card-text"><?php echo e($item->item_category); ?></p>
                                <hr>
                                <h6>Description</h6>
                                <p class="card-text"><?php echo e($item->bdesc); ?></p>
                            </div>

                        </div>
                    </div>
                </div>
                </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
        </div>



        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script>
            $(document).ready(function () {
                $('input[type=checkbox]').on('change', function () {
                    $('#search-form').submit();
                });
            });
        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./components/mainNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DARREN ENGELBERT\Desktop\BINUS\SEM5\Web Programming\Project Web Programming\Project_Lab\resources\views/Search.blade.php ENDPATH**/ ?>