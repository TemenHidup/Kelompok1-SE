

<?php $__env->startSection('title', 'Xiao Ding Dong'); ?>


<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class = "text-warning">交易记录 | Transaction History</h1>

    <?php if($th->isEmpty()): ?>
        <div class="container" style="background-color: rgb(37, 37, 37); height:40px; text-align:center; color:white"><h5>Food is not available</h5></div>
        <?php else: ?>
        <table class="table">
    <thead style="background-color:rgb(22, 22, 22)">
      <tr>
        <th scope="col"class="text-warning text-center" style="width: 20%;">Transaction ID</th>
        <th scope="col"class="text-warning text-center" style="width: 20%;">Purchase Date</th>
        <th scope="col"class="text-warning text-center" style="width: 40%;">Food Name</th>
        <th scope="col"class="text-warning text-center" style="width: 20%;">Total Price</th>
        
      </tr>
    </thead>
    <tbody style="background-color:rgb(72, 72, 72)">
    <?php $__currentLoopData = $th; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $ths->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-white text-center"><?php echo e($td->transaction_id); ?></td>
        <td class="text-white text-center"><?php echo e($td->created_at->format('Y-m-d')); ?></td>
        <td class="text-white text-center"><?php echo e($td->food->item_name); ?>[x<?php echo e($td->quantity); ?>]</td>
        <td class="text-white text-center">$<?php echo e($td->food->item_price * $td->quantity); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('./components/mainNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DARREN ENGELBERT\Desktop\BINUS\SEM5\Web Programming\Project Web Programming\Project_Lab\resources\views/Transaction.blade.php ENDPATH**/ ?>